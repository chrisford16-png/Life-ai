# LIFE AI — Real AI connection (v3)

This continues the LIFE AI Free Starter v2 project. The browser app now sends chat messages to `/api/chat`. The API key is read only by the server and is never sent to the browser.

## What is included

- `index.html` — LIFE AI front end, updated to call the real AI endpoint.
- `api/chat.js` — server-side endpoint that calls the OpenAI Chat Completions API.
- `vercel.json` — Vercel function and basic security headers.
- `manifest.webmanifest`, `sw.js` — installable/offline app support.
- `.env.example` — names of the server environment variables (no real key).

## Important: free for app users does not mean free to operate

You can keep LIFE AI free to download and use. However, real AI responses are billed by the AI provider based on usage, and hosting may have limits or costs. The app owner pays those charges unless a sponsor or other funding source covers them. Set a spending limit/budget alert with the provider before inviting users. Do not promise unlimited AI use at no cost.

## Setup (one time)

1. Create an account with the AI API provider and create an API key. Keep the key private.
2. Deploy this project to Vercel (import the project repository or use the Vercel CLI).
3. In the Vercel project settings, add these **Environment Variables**:
   - `OPENAI_API_KEY` = your secret API key
   - `OPENAI_MODEL` = `gpt-4.1-mini` (or another model available to your API account)
4. Redeploy after adding the variables.
5. Open the deployed HTTPS site and send a test message in LIFE AI.

Never paste the API key into `index.html`, `sw.js`, a public Git repository, or a chat message.

## Local testing

Use Node.js 20+ and Vercel CLI:

```bash
npm install -g vercel
vercel dev
```

Set `OPENAI_API_KEY` in your local environment before running `vercel dev`, or use a local `.env.local` file (do not commit it).

## Before a public launch

The included in-memory per-IP request guard is only a basic prototype safeguard. Serverless instances do not share memory, so it is not a reliable production rate limiter. Before a public launch, add a shared rate limiter (for example Redis/Upstash or a Cloudflare Durable Object), abuse monitoring, budget alerts, privacy notice, and clear retention rules. Do not collect account data until authentication and secure storage are implemented.

## Current limitations

- AI chat is real once the server key is configured and the project is deployed.
- Business Builder, Idea Studio, Learning Center, tasks, and notes remain the starter features from v2; the planning tools still use local starter templates.
- Tasks and notes are stored in the visitor's browser, not synced across devices.
- No login, cloud sync, voice, image generation, or native app-store package yet.
