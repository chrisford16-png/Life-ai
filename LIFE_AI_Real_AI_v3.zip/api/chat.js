// LIFE AI secure server-side AI endpoint for Vercel.
// Set OPENAI_API_KEY in the hosting provider's Environment Variables.
// Never put the API key in index.html or any browser-side JavaScript.

const WINDOW_MS = 60_000;
const MAX_REQUESTS_PER_WINDOW = 12;
const requestsByIp = new Map(); // Basic per-instance guard; use a shared rate limiter for production.

function send(res, status, body) {
  res.status(status).setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  return res.end(JSON.stringify(body));
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return send(res, 405, { error: "Use POST for chat requests." });
  }

  const key = process.env.OPENAI_API_KEY;
  if (!key) return send(res, 503, { error: "The AI service is not configured yet. The app owner must add OPENAI_API_KEY to the server environment." });

  const forwarded = req.headers["x-forwarded-for"];
  const ip = (Array.isArray(forwarded) ? forwarded[0] : (forwarded || "unknown")).split(",")[0].trim();
  const now = Date.now();
  const entry = requestsByIp.get(ip);
  if (entry && now - entry.start < WINDOW_MS && entry.count >= MAX_REQUESTS_PER_WINDOW) {
    return send(res, 429, { error: "You're sending messages too quickly. Please wait a minute and try again." });
  }
  if (!entry || now - entry.start >= WINDOW_MS) requestsByIp.set(ip, { start: now, count: 1 });
  else entry.count += 1;

  let body = req.body;
  if (typeof body === "string") {
    try { body = JSON.parse(body); } catch { return send(res, 400, { error: "Request body must be valid JSON." }); }
  }
  const incoming = Array.isArray(body?.messages) ? body.messages : [];
  const messages = incoming
    .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
    .slice(-12)
    .map(m => ({ role: m.role, content: m.content.trim().slice(0, 4000) }))
    .filter(m => m.content.length);

  if (!messages.length || messages[messages.length - 1].role !== "user") {
    return send(res, 400, { error: "Send a message before asking LIFE AI to reply." });
  }

  try {
    const upstream = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        messages: [
          { role: "system", content: "You are LIFE AI, a helpful everyday assistant. Be practical, clear, supportive, and honest. Break complicated tasks into manageable steps. Ask one focused follow-up question when necessary. Do not claim to have taken actions you have not taken. For medical, legal, financial, or safety matters, provide general information and encourage appropriate professional help." },
          ...messages
        ],
        max_completion_tokens: 700,
        temperature: 0.7
      })
    });

    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      // Do not send provider details or secrets to the browser.
      console.error("LIFE AI provider error:", upstream.status, data?.error?.message || "Unknown provider error");
      if (upstream.status === 401) return send(res, 502, { error: "The AI provider rejected the server key. Check the API key in hosting settings." });
      if (upstream.status === 429) return send(res, 503, { error: "The AI provider is busy or its usage limit has been reached. Please try again later." });
      return send(res, 502, { error: "The AI provider could not complete that request. Please try again shortly." });
    }
    const reply = data?.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) return send(res, 502, { error: "The AI provider returned an empty response. Please try again." });
    return send(res, 200, { reply: reply.trim() });
  } catch (error) {
    console.error("LIFE AI server error:", error?.message || error);
    return send(res, 500, { error: "Something went wrong on the AI server. Please try again." });
  }
}