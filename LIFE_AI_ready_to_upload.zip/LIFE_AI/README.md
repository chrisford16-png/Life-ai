# LIFE AI — Free Starter App

This is a small installable Progressive Web App (PWA) that runs on Android and desktop browsers.

## Included features
- Home dashboard and navigation
- Starter chat with local template-based replies
- Business-plan, idea and learning-path generators
- Task list saved in the browser on the current device
- Offline app shell through a service worker

## Important limitation
The chat in this starter is **not connected to a live AI model**. Its replies are local starter templates. A real AI assistant requires a backend service and an AI provider API key. Do not put a secret API key in `index.html` or any browser JavaScript. API usage may have a cost; the app shell itself is free to host on a static host.

## Run it
Service workers require `localhost` or HTTPS. Do not open `index.html` directly as a `file://` URL.

### Quick local test
If Python is installed, open a terminal in this folder and run:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

### Publish it
Upload the four files/folder contents to any static host that supports HTTPS. Open the HTTPS address on your Android device, then use the browser menu and choose **Install app** or **Add to Home screen** (wording varies).

## Privacy
Tasks are stored in browser `localStorage` on the device. They are not synced between devices and may be cleared if browser data is deleted. Avoid entering sensitive information.
