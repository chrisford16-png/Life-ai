# LIFE AI — Free Starter Prototype

This is a responsive, installable-web-app starter for LIFE AI.

## Run it
- Open `index.html` in a browser for the basic prototype.
- For install/PWA support, serve this folder over HTTPS or localhost (for example with VS Code Live Server or `python -m http.server 8000`).
- Visit the local URL on your phone and use the browser's Add to Home Screen / Install option.

## Included
- Responsive mobile and desktop layout
- Home dashboard and navigation
- Starter chat interface with local template responses
- Business-plan, idea and learning-path generators
- Task list saved in browser localStorage
- Basic service worker and web app manifest

## Important: what is not connected yet
The chat is a local demo, not a live AI model. This prototype makes no paid API calls and requires no API key. To provide real AI answers, connect an AI provider through a secure backend/serverless function. Do not put secret API keys in browser JavaScript. A free app can still incur hosting, AI inference, domain, app-store, or payment-processing costs as usage grows.

## Next development milestones
1. Choose a backend and AI provider with a clear spending cap.
2. Add secure authentication and cloud-synced conversations.
3. Add rate limits and abuse protection before public launch.
4. Add privacy policy, terms, accessibility checks and testing.
5. Package/publish native apps only when ready; app-store developer accounts may have fees.
